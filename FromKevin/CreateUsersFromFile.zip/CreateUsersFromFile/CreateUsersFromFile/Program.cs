﻿using System;
using System.IO;
using System.Linq;

namespace CreateUsersFromFile
{
    class Program
    {
        static void Main(string[] args)
        {
            var filePath = @"C:\source-code\throw-away\CreateUsersFromFile\testFile.txt";

            var lines = File.ReadAllLines(filePath);
            var users = lines
                .Select(line => line.Split(new string[]{"|"}, StringSplitOptions.RemoveEmptyEntries)) // split each line by pipe
                .Select(split => new User   // convert each line into a "user" object
            {
                FirstName = split[0],
                LastName = split[1],
                SISId = split[2],
                CRMId = split[3],
                EmailAddress = split[4],
                Username = split[5],
                Password = split[6],
                ExtraData = split[7]
            }).ToList(); // convert the users into a list of users

            // do what ever you need to with it



            // end program


            Console.WriteLine("Hello World!");
        }
    }
}
