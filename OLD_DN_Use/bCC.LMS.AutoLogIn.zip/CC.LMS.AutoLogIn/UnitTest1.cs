﻿/*
BTK - BethelTech
CCP - CoderCamps 
NAU - NorthArizona
SCI - SouthernCareers
WOL - WashingtonOnLine
WOZ - WOZU
 */

using System;
using System.IO;
using Utility;
using System.Diagnostics;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;

using System.Drawing;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CC.LMS.AutoLogIn
{
    [TestClass]
    public class UnitTest1
    {
        static Size BrowserSize = new Size(1206, 850);
        public static string UserName = string.Empty;
        public static string Password = String.Empty;
        static string TestName = Properties.Settings.Default.TestName;
        static string ChromePath = Directory.GetCurrentDirectory() + "\\assets\\";

        static string logPath = Properties.Settings.Default.LogPath +
                                Properties.Settings.Default.TestName + DateTime.Now.ToString("-MM-dd-HHmm");

        Utilities utility = new Utilities(logPath);

        [TestMethod]
        public void BethelTechPageLoad()
        {
            var newLine = Environment.NewLine;
            string subTest = "Bethal_Login";
            string searchText = Properties.Settings.Default.BethelTechIconSearch;
            string targetUrl = Properties.Settings.Default.BethelTechURL;
            string userAlias = Properties.Settings.Default.BethelAdmin;
            string userPwd = Properties.Settings.Default.Passwords;

            if (!Directory.Exists(logPath))
            {
                Directory.CreateDirectory(logPath);
                utility.MakeLogEntry("Testing Bethel Tech start ==>" + DateTime.UtcNow.Ticks.ToString() + newLine);
            }
            else
            {
                utility.MakeLogEntry("Testing Bethel Tech start ==>" + DateTime.UtcNow.Ticks.ToString() + newLine);
            }


            using (IWebDriver webDriver = new ChromeDriver(ChromePath))
            {
                webDriver.Navigate().GoToUrl(targetUrl);
                utility.RandomPause(2);
                webDriver.Manage().Window.Size = BrowserSize;
                utility.RandomPause(2);
                string pageText = webDriver.PageSource.ToString();

                try
                {
                    Assert.IsTrue(pageText.Contains(searchText));
                    {
                        utility.MakeLogEntry("Pass, text found" + newLine + searchText);
                        searchText = string.Empty;
                    }
                }
                catch (Exception expText)
                {
                    utility.MakeLogEntry("FAILED" + newLine + expText);
                    utility.MakeLogEntry("Searched text failed" + newLine + searchText);
                    searchText = string.Empty;
                    Assert.Fail();
                }

                webDriver.FindElement(By.Id("Username")).SendKeys(userAlias);
                webDriver.FindElement(By.Id("Password")).SendKeys(userPwd);
                webDriver.FindElement(By.ClassName("cc-btn-sign-in")).Click();
                utility.RandomPause(5);
                pageText = webDriver.PageSource;
                searchText = "Search for a cohort";

                try
                {
                    Assert.IsTrue(pageText.Contains(searchText));
                    {
                        utility.MakeLogEntry("Log On succeeded for" + userAlias);
                        webDriver.FindElement(By.PartialLinkText("Logout")).Click();
                        searchText = string.Empty;
                    }
                }
                catch (Exception expText)
                {
                    utility.MakeLogEntry("Log On Failed for client " + newLine + userAlias);
                    utility.MakeLogEntry("Exception Code" + newLine + expText);
                    Assert.Fail();
                }

                try
                {
                    utility.RandomPause(2);
                    pageText = webDriver.PageSource;
                    searchText = "You have been logged out of Exeter";

                    Assert.IsTrue(pageText.Contains(searchText));
                    {
                        utility.MakeLogEntry("PASSED" + newLine +
                            "Log In, Authentication, Log Off all passed");
                    }
                }
                catch (Exception expText)
                {
                    utility.MakeLogEntry("LOG OFF Failed error Was " + newLine + expText);
                    Assert.Fail();
                }

            webDriver.Close();
            }
        }//EOT BETHEL
        

        [TestMethod]
        public void CoderCampsPageLoad()
        {
            var newLine = Environment.NewLine;
            string searchText = Properties.Settings.Default.CoderCampsIconSearch;
            string targetUrl = Properties.Settings.Default.CoderCampsURL;

            if (!Directory.Exists(logPath))
            {
                Directory.CreateDirectory(logPath);
                utility.MakeLogEntry("Testing Coder Camps start ==>" + DateTime.UtcNow.Ticks.ToString() + newLine);
            }
            else
            {
                utility.MakeLogEntry("Testing Coder Camps start ==>" + DateTime.UtcNow.Ticks.ToString() + newLine);
            }


            using (IWebDriver webDriver = new ChromeDriver(ChromePath))
            {
                webDriver.Navigate().GoToUrl(targetUrl);
                utility.RandomPause(2);
                webDriver.Manage().Window.Size = BrowserSize;
                utility.RandomPause(2);
                string pageText = webDriver.PageSource.ToString();

                try
                {
                    Assert.IsTrue(pageText.Contains(searchText));
                    {
                        utility.MakeLogEntry("Pass we found ==>" + newLine + searchText);
                        utility.RandomPause(3);
                    }
                }
                catch (Exception expText)
                {
                    utility.MakeLogEntry("FAILED :: FAILED :: FAILED" + newLine + expText);
                    utility.MakeLogEntry("The text we searched for wasn't there  " + newLine + searchText);
                    Assert.Fail();
                }
                webDriver.Close();
            }

        }//EOT CoderCamps
        

        [TestMethod]
        public void NorthernArizonaPageLoad()
        {
            var newLine = Environment.NewLine;
            string searchText = Properties.Settings.Default.NorthernArizonaIconSearch;
            string targetUrl = Properties.Settings.Default.NorthernArizonaURL;

            if (!Directory.Exists(logPath))
            {
                Directory.CreateDirectory(logPath);
                utility.MakeLogEntry("Testing NAU start ==>" + DateTime.UtcNow.Ticks.ToString() + newLine);
            }
            else
            {
                utility.MakeLogEntry("Testing NAU start ==>" + DateTime.UtcNow.Ticks.ToString() + newLine);
            }


            using (IWebDriver webDriver = new ChromeDriver(ChromePath))
            {
                webDriver.Navigate().GoToUrl(targetUrl);
                utility.RandomPause(2);
                webDriver.Manage().Window.Size = BrowserSize;
                utility.RandomPause(2);
                string pageText = webDriver.PageSource.ToString();

                try
                {
                    Assert.IsTrue(pageText.Contains(searchText));
                    {
                        utility.MakeLogEntry("Pass we found ==>" + newLine + searchText);
                        utility.RandomPause(3);
                    }
                }
                catch (Exception expText)
                {
                    utility.MakeLogEntry("FAILED :: FAILED :: FAILED" + newLine + expText);
                    utility.MakeLogEntry("The text we searched for wasn't there  " + newLine + searchText);
                    Assert.Fail();
                }
                webDriver.Close();
            }

        }//EOT Northern Arizona
        

        [TestMethod]
        public void SouthernCareersPageLoad()
        {
            var newLine = Environment.NewLine;
            string searchText = Properties.Settings.Default.SouthernCareersIconSearch;
            string targetUrl = Properties.Settings.Default.SouthernCareersURL;

            if (!Directory.Exists(logPath))
            {
                Directory.CreateDirectory(logPath);
                utility.MakeLogEntry("Testing Southern Careers Inst start ==>" + DateTime.UtcNow.Ticks.ToString() + newLine);
            }
            else
            {
                utility.MakeLogEntry("Testing Southern Careers Inst start ==>" + DateTime.UtcNow.Ticks.ToString() + newLine);
            }


            using (IWebDriver webDriver = new ChromeDriver(ChromePath))
            {
                webDriver.Navigate().GoToUrl(targetUrl);
                utility.RandomPause(2);
                webDriver.Manage().Window.Size = BrowserSize;
                utility.RandomPause(2);
                string pageText = webDriver.PageSource.ToString();

                try
                {
                    Assert.IsTrue(pageText.Contains(searchText));
                    {
                        utility.MakeLogEntry("Pass we found ==>" + newLine + searchText);
                        utility.RandomPause(3);
                    }
                }
                catch (Exception expText)
                {
                    utility.MakeLogEntry("FAILED :: FAILED :: FAILED" + newLine + expText);
                    utility.MakeLogEntry("The text we searched for wasn't there  " + newLine + searchText);
                    Assert.Fail();
                }
                webDriver.Close();
            }

        }//EOT Southern Careers
        

        [TestMethod]
        public void WashingtonOnLinePageLoad()
        {

            var newLine = Environment.NewLine;
            string searchText = Properties.Settings.Default.WashingtonOnLineIconSearch;
            string targetUrl = Properties.Settings.Default.WashingtonOnLineURL;


            if (!Directory.Exists(logPath))
            {
                Directory.CreateDirectory(logPath);
                utility.MakeLogEntry("Testing Washington OnLine Inst start ==>" + DateTime.UtcNow.Ticks.ToString() + newLine);
            }
            else
            {
                utility.MakeLogEntry("Testing Washington OnLine Inst start ==>" + DateTime.UtcNow.Ticks.ToString() + newLine);
            }


            using (IWebDriver webDriver = new ChromeDriver(ChromePath))
            {
                webDriver.Navigate().GoToUrl(targetUrl);
                utility.RandomPause(2);
                webDriver.Manage().Window.Size = BrowserSize;
                utility.RandomPause(2);
                string pageText = webDriver.PageSource.ToString();

                try
                {
                    Assert.IsTrue(pageText.Contains(searchText));
                    {
                        utility.MakeLogEntry("Pass we found ==>" + newLine + searchText);
                        utility.RandomPause(3);
                    }
                }
                catch (Exception expText)
                {
                    utility.MakeLogEntry("FAILED :: FAILED :: FAILED" + newLine + expText);
                    utility.MakeLogEntry("The text we searched for wasn't there  " + newLine + searchText);
                    Assert.Fail();
                }
                webDriver.Close();
            }


        }//EOT Washington OnLine
        

        [TestMethod]
        public void WOZUniversityPageLoad()
        {

            var newLine = Environment.NewLine;
            string searchText = Properties.Settings.Default.WOZUniversityIconSearch;
            string targetUrl = Properties.Settings.Default.WOZUnversityURL;

            if (!Directory.Exists(logPath))
            {
                Directory.CreateDirectory(logPath);
                utility.MakeLogEntry("Testing WOZ U start ==>" + DateTime.UtcNow.Ticks.ToString() + newLine);
            }
            else
            {
                utility.MakeLogEntry("Testing WOZ U start ==>" + DateTime.UtcNow.Ticks.ToString() + newLine);
            }


            using (IWebDriver webDriver = new ChromeDriver(ChromePath))
            {
                webDriver.Navigate().GoToUrl(targetUrl);
                utility.RandomPause(2);
                webDriver.Manage().Window.Size = BrowserSize;
                utility.RandomPause(2);
                string pageText = webDriver.PageSource.ToString();

                try
                {
                    Assert.IsTrue(pageText.Contains(searchText));
                    {
                        utility.MakeLogEntry("Pass we found ==>" + newLine + searchText);
                        utility.RandomPause(3);
                    }
                }
                catch (Exception expText)
                {
                    utility.MakeLogEntry("FAILED :: FAILED :: FAILED" + newLine + expText);
                    utility.MakeLogEntry("The text we searched for wasn't there  " + newLine + searchText);
                    Assert.Fail();
                }
                webDriver.Close();
            }


        }//EOT WOZ Unversity
        


    }//EOC
}//EONS


/*
    //Intentionally replaced searchText with an expected fail
    searchText = "Fuzzy Bunny Search Text!";
*/